<div class="wrap">

	<div id="icon-tools" class="icon32"></div>
	<h2>WP Survey And Quiz Tool</h2>

	<?php echo $message; ?>
	
</div>