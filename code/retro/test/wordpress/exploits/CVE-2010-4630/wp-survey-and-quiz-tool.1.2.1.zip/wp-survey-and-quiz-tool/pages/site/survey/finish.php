<h1><?php echo $surveyName; ?></h1>

<p>Thank you for completing out survey!</p>